@echo off
rem ============================================================
rem  soundLAB desktop installer for Windows
rem
rem  Creates Desktop + Start Menu shortcuts that open soundLAB
rem  in its own app window (Edge/Chrome app mode - no tabs, no
rem  address bar). MIDI keyboards work natively: Chromium's
rem  built-in Web MIDI is the bridge - approve the MIDI prompt
rem  on first run. The app itself works offline after the first
rem  visit (it is a PWA) and auto-updates.
rem ============================================================
setlocal
set "URL=https://mreindl118-boop.github.io/GuitarPak/"
set "PF86=%ProgramFiles(x86)%"

set "BROWSER="
if exist "%PF86%\Microsoft\Edge\Application\msedge.exe" set "BROWSER=%PF86%\Microsoft\Edge\Application\msedge.exe"
if not defined BROWSER if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" set "BROWSER=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if not defined BROWSER if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set "BROWSER=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not defined BROWSER if exist "%PF86%\Google\Chrome\Application\chrome.exe" set "BROWSER=%PF86%\Google\Chrome\Application\chrome.exe"
if not defined BROWSER if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" set "BROWSER=%LocalAppData%\Google\Chrome\Application\chrome.exe"

if not defined BROWSER (
  echo Could not find Microsoft Edge or Google Chrome.
  echo Install either one, then run this installer again.
  pause
  exit /b 1
)

echo Using browser: %BROWSER%

rem fetch the soundLAB icon so the shortcuts carry the real app icon
set "ICODIR=%LocalAppData%\soundLAB"
set "ICO=%ICODIR%\soundLAB.ico"
if not exist "%ICODIR%" mkdir "%ICODIR%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "try { Invoke-WebRequest -UseBasicParsing 'https://github.com/mreindl118-boop/GuitarPak/raw/main/icons/soundlab.ico' -OutFile '%ICO%' } catch { }"

powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws=New-Object -ComObject WScript.Shell; $l=$ws.CreateShortcut([Environment]::GetFolderPath('Desktop')+'\soundLAB.lnk'); $l.TargetPath='%BROWSER%'; $l.Arguments='--app=%URL%'; $l.Description='soundLAB - guitar + keys practice and studio'; if (Test-Path '%ICO%') { $l.IconLocation='%ICO%,0' }; $l.Save()"
if errorlevel 1 goto :fail

powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws=New-Object -ComObject WScript.Shell; $d=Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'; $l=$ws.CreateShortcut((Join-Path $d 'soundLAB.lnk')); $l.TargetPath='%BROWSER%'; $l.Arguments='--app=%URL%'; $l.Description='soundLAB - guitar + keys practice and studio'; if (Test-Path '%ICO%') { $l.IconLocation='%ICO%,0' }; $l.Save()"
if errorlevel 1 goto :fail

echo.
echo Installed. soundLAB is now on your Desktop and in the Start Menu.
echo.
echo First run tips:
echo   - On Windows, connect your MIDI keyboard by USB for browser MIDI.
echo     Bluetooth pairing alone may not expose a MIDI port to the browser.
echo   - Select the keyboard's LED output in soundLAB's Settings and allow MIDI.
echo     For a LUMI with a generic port name, select Keyboard type LUMI.
echo   - The app keeps working offline after the first visit.
echo.
choice /c YN /m "Launch soundLAB now"
if errorlevel 2 exit /b 0
start "" "%BROWSER%" --app=%URL%
exit /b 0

:fail
echo Shortcut creation failed.
pause
exit /b 1
